# Application 1, logit model
# the seed for the optimal design we used for the 1-100

# Figure 
# beta = (-3, 4, 6, 1)

# D-optimality ------------------------------------------------------------
# n = 10, seed = 70
# n = 15, seed = 84
# n = 20, seed = 93