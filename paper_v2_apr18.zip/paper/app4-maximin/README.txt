README file

The seed I used to construct the maximin D-OAD is 
n = 10, seed = 1,  loss = 0.83709
n = 20, seed = 7,  loss = 0.84198
n = 30, seed = 97, loss = 0.84585

For  the maximin A-OED, I have
n = 10, seed = 48, loss = 0.68125
n = 20, seed = 94, loss = 0.69826
n = 30, seed = 73, loss = 0.71212