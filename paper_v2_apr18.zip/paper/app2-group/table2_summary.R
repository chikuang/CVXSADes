# Application 2, group design
# the seed for the optimal design we used for the 1-100

# Table 2

# D-optimality ------------------------------------------------------------
# n = 10, seed = 20
# n = 11, seed = 3
# n = 12, seed = 42
# n = 13, seed = 22
# n = 14, seed = 8

# c-optimality -------------------------------------------------------------
# n = 10, seed = 6
# n = 11, seed = 45
# n = 12, seed = 44
# n = 13, seed = 39
# n = 14, seed = 17

